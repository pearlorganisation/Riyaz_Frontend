const About = () => {
  return <div>About Us Page</div>;
};

export default About;
